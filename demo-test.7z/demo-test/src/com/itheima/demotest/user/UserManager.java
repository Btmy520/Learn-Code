package com.itheima.demotest.user;

import java.util.ArrayList;
import java.util.List;

public class UserManager {
    private final List<User> userDataBase = new ArrayList<>();

    public void printAllUsers(){
        System.out.println("==========");
        for (User user: userDataBase){

            System.out.println(user);
        }
        System.out.println("==========");
    }

    public void initUsers(int n){
        for (int i = 0; i < n; i++) {
            String userName = "user" + i;
            User user = new User(userName);
            userDataBase.add(user);
        }

    }

    public boolean registerUser(String userName, String password){
        for (User user: userDataBase){
            if (user.getUserName().equals(userName)){
                return false;
            };
            User newUser = new User(userName, password);
            userDataBase.add(newUser);
        }
        return true;
    }

    public boolean loginUser(String userName, String password){
        for (User user: userDataBase){
            if (user.getUserName().equals(userName) && user.getPassWord().equals(password)){
                return false;
            };
        }
        return true;
    }
//临时代码

}
