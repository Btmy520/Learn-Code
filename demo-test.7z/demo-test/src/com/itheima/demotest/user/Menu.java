package com.itheima.demotest.user;

import java.util.Scanner;

public class Menu {
    // 打印菜单项

    private Scanner inputScanner;
    private UserManager userManager;

    public Menu(UserManager userManager) {
        this.inputScanner = new Scanner(System.in);
        this.userManager = userManager;
    }

    // 显示主菜单界面
    public void showMainMenu() {
        while (true) {
            printMenu();
            int choice = inputScanner.nextInt();
            inputScanner.nextLine();
            switch (choice) {
                case 1:
                    registrationMenu();
                    break;
                case 2:
                    loginMenu();
                    break;
                case 3:
                    System.out.println("退出系统");
                    inputScanner.close();
                    System.exit(0);
                default:
                    System.out.println("输入错误，请重新选择");
            }
        }
    }
    private void printMenu() {
        System.out.println("请输入数字进行操作：");
        System.out.println("1. 注册");
        System.out.println("2. 登录");
        System.out.println("3. 退出");
    }

    // 用户注册子界面
    private void registrationMenu() {
        System.out.println("请输入用户名：");
        String username = inputScanner.nextLine();
        System.out.println("请输入密码：");
        String password = inputScanner.nextLine();
        if (userManager.registerUser(username, password)) {
            System.out.println("注册成功");
        } else {
            System.out.println("用户名已存在");
        }
    }

    // 用户登录子界面
    private void loginMenu() {
        System.out.println("请输入用户名：");
        String username = inputScanner.nextLine();
        System.out.println("请输入密码：");
        String password = inputScanner.nextLine();
        if (userManager.loginUser(username, password)) {
            System.out.println("登录成功");
        } else {
            System.out.println("认证失败");
        }
    }
}
