package com.itheima.demotest.user;

import java.util.ArrayList;
import java.util.List;

public class User {
    private String userName;
    private String passWord;

    public User() {
    }

    public User(String userName, String passWord) {
        this.userName = userName;
        this.passWord = passWord;
    }

    public User(String userName) {
    }


    public String getUserName() {
        return userName;
    }


    public void setUserName(String userName) {
        this.userName = userName;
    }


    public String getPassWord() {
        return passWord;
    }


    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }

    public String toString() {
        return "用户名" + userName + ", 密码 = " + passWord + "}";
    }

    List<User> userDateBase = new ArrayList<>();
    public void userDate(){
        for(User user:userDateBase){
            System.out.println(user);
        }
    }

    public void userName(int n){
        for (int i = 0; i < n; i++) {
            String userName = "user" + i;
            User Nuser = new User(userName);
            userDateBase.add(Nuser);
        }
    }
}
