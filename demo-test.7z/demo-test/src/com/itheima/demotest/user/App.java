package com.itheima.demotest.user;

public class App {
    public static void main(String[] args) {
        UserManager um = new UserManager();
        um.initUsers(3);
        um.printAllUsers();
        um.loginUser("zhangsan","123");


    }

}
