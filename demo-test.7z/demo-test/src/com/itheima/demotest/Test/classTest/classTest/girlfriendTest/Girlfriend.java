package com.itheima.demotest.Test.classTest.classTest.girlfriendTest;

public class Girlfriend {
    private String name;
    private int age;
    //转换为私有制
    //获取名字
    public void SetName(String name) {
        String n = name;
        System.out.println(n);
    }
    public String GetName() {
        return name;
    }
    //获取年龄
    public void SetAge(int age) {
        int a = age;//0
        if (age >= 18 && age <= 35) {
            age = a;//赋值
            System.out.println(this.age);
        }else{
            System.out.println("非法的数据");
        }
    }
    public int GetAge(){
        return age;
    }

    //就近原则和this
    //this(不要用它)

    //行为

    public void eat(){
        System.out.println("女朋友爱吃的东西");
    }
    public void sleep(){
        System.out.println("女朋友爱睡觉");
    }
}
