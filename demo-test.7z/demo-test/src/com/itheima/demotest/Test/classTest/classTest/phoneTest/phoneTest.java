package com.itheima.demotest.Test.classTest.classTest.phoneTest;

public class phoneTest {
    public static void main(String[] args) {
        //定义一个类
        Phone p = new Phone();

        //赋值
        p.brand = "oppo";
        p.price = 5499.00;
        //调用手机的行为
        p.playGame();
        p.call();

        //定义第二部手机(类)

    }


}
