package com.itheima.demotest.Test.classTest.classTest.phoneTest;

public class Phone {
    //属性
    String brand;
    double price;
    //行为
    public void playGame() {
        System.out.println("手机正在玩游戏");
    }
    public void call() {
        System.out.println("手机正在打电话");
    }

}
