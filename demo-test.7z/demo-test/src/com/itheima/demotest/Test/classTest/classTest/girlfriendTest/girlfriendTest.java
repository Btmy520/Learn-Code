package com.itheima.demotest.Test.classTest.classTest.girlfriendTest;

public class girlfriendTest {
    public static void main(String[] args) {
        Girlfriend g =new Girlfriend();
        g.SetAge(18);
        g.SetName("Btmy");

        //行为
        g.eat();
        g.sleep();

    }
}
