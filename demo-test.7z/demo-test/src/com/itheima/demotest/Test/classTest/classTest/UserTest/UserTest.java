package com.itheima.demotest.Test.classTest.classTest.UserTest;

public class UserTest {
    public static void main(String[] args) {

    }
}
