package com.itheima.demotest.Test;

import java.util.Scanner;

public class test04 {
    public static void main(String[] args) {
        //定义方法判断数组中是否存在这个数字,将结果返回调用处
        int[] arr = {1,4,7,23,654,23,2,3,9};
        boolean srch = srch(arr,23);
        System.out.println(srch);
    }
    public static boolean srch(int[] arr, int number){
        for (int i = 0; i < arr.length; i++) {
            if( arr[i] == number){
                return true;
            }
        }
        return false;
    }
    //break和return的区别
    //return:和循环无关,和方法有关,1.表示返回结果,2.表示返回方法
    //如方法执行到return,则整个方法内全部结束

    //break:与方法无关,和循环有关,
    //运行到break之后整个if循环或者switch结束,但是方法不结束
}
