package com.itheima.demotest.Test.testPro;

import java.util.Scanner;

public class testPro01 {
    public static void main(String[] args) {
        //机票价格按照淡季旺季,头等舱,经济舱来收费,输入机票原价,月份,头等舱或经济舱
        //旺季(5-10月份)头等舱打9折,经济舱打8,5折,淡季(11-来年4月份)头等舱打7七折.经济舱6.5折

        //键盘录入机票原价,月份,头等舱或经济舱
        Scanner sc = new Scanner(System.in);
        System.out.print("请输入机票价格:");
        int ticket = sc.nextInt();
        System.out.print("请输入当前月份:");
        int month = sc.nextInt();
        System.out.println("请输入飞机仓位:(输入0代表经济舱,输入1代表头等舱):");
        int seat = sc.nextInt();
        //判断月份为淡季还是旺季
        /////////////////////////////////////
        if (month >= 5 && month <= 10) {
            //引入旺季折扣
           ticket = getTicket(ticket, seat,0.9,0.85);
        }else if ((month >= 11 && month <= 12) || (month >= 1 && month <= 4)) {
            //引入淡季折扣
           ticket = getTicket(ticket, seat,0.7,0.65);
        }else{
            System.out.println("错误!请输入正确的月份(1-12");
        }
        System.out.println(ticket);
    }
    public static int getTicket(int ticket, int seat, double v0, double v1) {
        //设置方法简化代码
        //判断飞机舱位
        if (seat >= 1) {
            ticket = (int)(ticket * v0);//第一个折扣
        }else if (seat == 0) {
            ticket = (int)(ticket * v1);//第二个折扣
        }else{
            System.out.println("请输入正确的机舱!");
        }
        return ticket;
    }
}
