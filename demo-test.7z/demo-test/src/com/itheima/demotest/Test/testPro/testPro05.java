package com.itheima.demotest.Test.testPro;

import java.util.Scanner;

public class testPro05 {
    public static void main(String[] args) {
        //6个评委打分,分数范围是[0-100]的整数
        //去掉一个最高分,去掉一个最低分,取中间四名评委分数的平均值
        //定义一个数组
        int[] score = arrScore();
        for (int i = 0; i < score.length; i++) {
            System.out.print(score[i] + " ");
        }
        int max = getMax(score);

        int min = getMin(score);

        int sum = Sum(score);

        int add = (sum - max - min) / (score.length - 2);

        System.out.println("最终得分是" + add);


    }
    public static int Sum(int[] score) {
        int sum = 0;
        for (int i = 0; i < score.length; i++) {
            sum = score[i] + sum;
        }
        return sum;
    }
    //求最大值
    public static int getMax(int[] score) {
        int max = score[0];
        for (int i = 1; i < score.length; i++) {
            if (max > score[i]) {
                max = score[i];
            }
        }
        return max;
    }
    //求最小值
    public static int getMin(int[] score) {
        int min = score[0];
        for (int i = 0; i < score.length; i++) {
            if (min < score[i]) {
                min = score[i];
            }
        }
        return min;
    }

    public static int[] arrScore(){
        int[] arrScore = new int[6];
        //键盘录入评委打分的数据
        Scanner sc = new Scanner(System.in);

        for (int i = 0; i < arrScore.length;) {

            System.out.print("请输入评委分数:");
            int score = sc.nextInt();

            if(score >-1 && score <= 100) {
                arrScore[i] = score;
                i++;
            }else{
                System.out.println("评委输出分数不正确,请重新输入,当前是第"+i+"位评委");
            }

        }
        return arrScore;
    }
}
