package com.itheima.demotest.Test.testPro;

public class testPro04 {
    public static void main(String[] args) {
        //将一个数组内的数据复制到另一个数组当中
        int[] arr = new int[]{1,2,3,4,5};
        int[] newArr = new int[arr.length];

        for (int i = 0; i < arr.length; i++) {
            //System.out.println(newAarr[i]);
            newArr[i] = arr[i];

        }
        for (int i = 0; i < newArr.length; i++) {
            System.out.println(arr[i]);
        }
    }
}
