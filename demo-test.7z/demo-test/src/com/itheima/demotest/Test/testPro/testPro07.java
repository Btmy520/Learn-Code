package com.itheima.demotest.Test.testPro;

public class testPro07 {
    public static void main(String[] args) {
        //把每一位放到数组当中
        int number = 12345;
        //定义一个变量临时记录number的值
        int temp = number;
        //定义一个统计变量
        int count = 0;
        while (number != 0) {
            number = number / 10;
            count++;
        }

        //初始化数组
        int[] arr = new int[count];
        int index = 0;
        while (temp != 0) {
            int ge = temp % 10;
            temp = temp / 10;
            index++;
        }
        System.out.println(arr[123]);



    }
}
