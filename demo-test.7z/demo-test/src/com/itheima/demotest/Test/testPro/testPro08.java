package com.itheima.demotest.Test.testPro;

import java.util.Random;

public class testPro08 {
    public static void main(String[] args) {
        //抽奖练习,抽五个奖项随机输出1,2,3,4,5
        //每个奖项输出不能重复
        //定义一个数组存储奖项
        int[] arr = new int[]{1,2,3,4,5};
        //临时变量输出抽奖出来的数据
        int[] newArr = new int[arr.length];
        for (int i = 0; i < arr.length; i++) {
            Random r = new Random();

        }

    }
}
