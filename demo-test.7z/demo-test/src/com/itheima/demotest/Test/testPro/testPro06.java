package com.itheima.demotest.Test.testPro;

import java.util.Scanner;

public class testPro06 {
    public static void main(String[] args) {
        //某系统的数字系统采用加密模式存储
        //先得到每位数,每位数字加5,对上10求余数
        int[] arr = new int[]{8,7,3,6};
        for (int i = 0; i < arr.length; i++) {
            arr[i] = arr[i] + 5;
            System.out.print(arr[i] + " ");


        }
        System.out.println();
        for (int i = 0; i < arr.length; i++) {
            arr[i] = arr[i] % 10 ;
            System.out.print(arr[i] + " ");

        }
        System.out.println();

        for (int i = 0, j = arr.length - 1; i < j; i++,j--) {
            int temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");

        }

        System.out.println();
        int num = 0;
        for (int i = 0; i < arr.length; i++) {
            num *= arr[i] * 10;
            System.out.print(arr[i]);
        }


    }
}
