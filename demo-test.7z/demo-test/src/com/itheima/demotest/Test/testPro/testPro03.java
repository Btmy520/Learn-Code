package com.itheima.demotest.Test.testPro;

import javax.swing.*;
import java.util.Random;

public class testPro03 {
    public static void main(String[] args) {
        /*定义方法生成随机五位数验证码
        验证码格式:
        五位数
        前四位是大写或小写字母
        后一位为数字
        */

        char[] words = new char[52];
        for (int i = 0; i < words.length; i++) {
            if (i <= 25) {
                words[i] = (char) ('a' + i);
            } else {
                words[i] = (char) (65 + i - 26);
            }
        }
        //空字符作为占位,验证码生成打印后覆盖
        String result = "";
        Random rand = new Random();

        for (int i = 0; i < 4; i++) {
            int randIndex = rand.nextInt(words.length);
            //System.out.print(words[randIndex]);
            //定义result输出前四位并覆盖空占位符
            result = result + words[randIndex];
        }
        //num在0-9数字中生成随机数
        int num = rand.nextInt(10);
        //生成最终验证码
        System.out.println(result + num);

        /*(for (int i = 0; i < words.length; i++) {
            System.out.print(words[i] + " ");


        }*/


    }
}
