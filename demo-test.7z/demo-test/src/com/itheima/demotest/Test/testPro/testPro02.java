package com.itheima.demotest.Test.testPro;

public class testPro02 {
    public static void main(String[] args) {
        //判断101-200之间有多少个质数
        //定义变量count作为质数数量记录
        int count = 0;
        for (int i = 101; i <= 200; i++) {
            boolean flag = true;//设定为质数
            //外循环,负责遍历101-200的数据
            for (int j = 2; j < i; j++) {
                //判断当前数字是否为质数
                if(i % j == 0){
                    flag = false;
                    break;
                }
                /*判断结束后,判断出来的质数输出
                并累加输出质数数量count*/
                }
            if(flag){
                System.out.println("当前数字" + i + "是质数");
                count++;
            }
        }
        //打印count表示质数数量
        System.out.println("有" + count + "个质数");
    }
}
