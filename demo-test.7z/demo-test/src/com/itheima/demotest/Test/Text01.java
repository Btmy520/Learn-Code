package com.itheima.demotest.Test;
//导包
import java.util.Scanner;
public class Text01 {
    public static void main(String[] args) {

        //键盘中录入一个三位数,提取其中的百位,十位,个位
        //键盘录入
        Scanner scr = new Scanner(System.in);
        System.out.println("输入一个三位数:");
        //数据处理
        int num = scr.nextInt();
        int ge=(num % 10);
        int shi=(num / 10 % 10);
        int bai=(num / 100 % 10);
        //数据输出
        System.out.println("个位数:" + ge);
        System.out.println("十位数:" + shi);
        System.out.println("百位数:" + bai);

    }
}
