package com.itheima.demotest.Test;

public class test05 {
    public static void main(String[] args) {

    }
}
