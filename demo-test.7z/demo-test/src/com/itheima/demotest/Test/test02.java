package com.itheima.demotest.Test;

public class test02 {
    public static void main(String[] args) {
        printArr();

    }

    public static void printArr() {
        int[] arr = {11,22,33,44,55};
        System.out.print("[");
        for (int i = 0; i < arr.length; i++) {

            if (i == arr.length - 1) {
                System.out.print(arr[i]);
            }else{
                System.out.print(arr[i] + ",");
            }
        }
        System.out.print("]");
    }
}
