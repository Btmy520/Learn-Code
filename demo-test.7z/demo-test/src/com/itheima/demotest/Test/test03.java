package com.itheima.demotest.Test;

public class test03 {
    public static void main(String[] args) {
        //设计方法求数组最大值并返回
        //定义数组
        int[] arr = {9,5,3,7,10,2};
        //ctrl + alt + v 自动引入max数据
        int max = print(arr);
        //输出打印
        System.out.println(max);
    }
    public static int print(int[] arr){
        //返回值返回位置
        int max = arr[0];
        for (int i = 0; i < arr.length; i++) {
            //遍历数组数据
            //如果遍历数据大于max则引入max
            if (max < arr[i]) {
                max = arr[i];
            }
        }
        //返回值
        return max;
    }
}
