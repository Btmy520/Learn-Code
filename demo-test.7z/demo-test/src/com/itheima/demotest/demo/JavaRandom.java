package com.itheima.demotest.demo;

import java.util.Random;
import java.util.Scanner;

public class JavaRandom {
    public static void main(String[] args) {
        Random rand = new Random();
        int number= rand.nextInt(100) + 1;
        int cont = 0;
        while (true){
            Scanner sc = new Scanner(System.in);
            System.out.println("输入猜的数字:");
            int guessNumber = sc.nextInt();
            if (guessNumber > number) {
                System.out.println("数字偏大");
            }else if(guessNumber < number){
                System.out.println("数字偏小");
                cont++;
                if(cont == 3){
                    System.out.println("残念!数字是" + number);
                }
            }else{
                System.out.println("bingooooooooooooooooooooooooooooooooo");
                break;
            }
        }
    }
}
