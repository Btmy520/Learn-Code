package com.itheima.demotest.demo;
import java.util.Scanner;
public class JavaDemo02 {
    //主入口
    public static void main(String[] args) {
        int A=10,B=3;
        Scanner sc = new Scanner(System.in);
        if(A%B==0){
            System.out.println("能被整除");
        }else{
            System.out.println("不能被整除");
        };
        if(A%2==0){
            System.out.println("A为偶数");
        }else{
            System.out.println("A为奇数");
        }

        //（￣︶￣）↗　
        System.out.println(10 / 3);
        System.out.println(10.0 / 3);
        //取模
        System.out.println(10.0 % 2);//0.0
        System.out.println(10.0 % 3);//1.0

        //应用场景
        //1.取模来判断A是否为B整除


    }
}
