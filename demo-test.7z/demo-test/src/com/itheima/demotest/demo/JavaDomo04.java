package com.itheima.demotest.demo;

import java.util.Scanner;

public class JavaDomo04 {
    public static void main(String[] args) {
        //键盘输入一个大于等于2的整数,设为x
        //并要求计算他的平方根,舍去浮点数
        Scanner sc = new Scanner(System.in);
        System.out.println("请属于一个大于等于2的整数,输入0退出:");
        int number = sc.nextInt();
        for (int i = 1; i <= number; i++) {
            if(i * i == number){//判断是否等于输入的数字
                System.out.println(i + "是" + number + "的平方根");
                break;
            }else if(i * i > number){//判断是否大于输入的数字
                System.out.println(i - 1 + "是" + number + "的平方根");
                break;
            }
        }
    }
}
