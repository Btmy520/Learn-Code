package com.itheima.demotest.demo;

public class SevenPass {
    public static void main(String[] args) {
        //输出数字1-100之间,数字含有7或是7的倍数喊过
        //1-100 含7数字,7的倍数(if?)
        for(int i = 1 ; i <= 100 ; i++){
            if(i % 10 == 7 || i / 10 % 10 == 7 || i % 7 ==0){
                System.out.println("pass");
                continue;
            }
            System.out.println(i);
        }
    }
}
