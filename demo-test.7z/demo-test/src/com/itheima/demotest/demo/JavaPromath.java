package com.itheima.demotest.demo;
import java.util.Scanner;
public class JavaPromath {

	public static void main(String[] args) {
        for(;;)
        {
                System.out.println("————————————————简易计算器————————————————");
                System.out.println("\t\t请输入0-5的数字");
                System.out.println("\t\t加法\t1");
                System.out.println("\t\t减法\t2");
                System.out.println("\t\t乘法\t3");
                System.out.println("\t\t除法\t4");
                System.out.println("——————————————————————————————————————————");
                Scanner sc = new Scanner(System.in);
                int select;
                System.out.print("请输入0-4的数字:");
                select = sc.nextInt();
                System.out.println("——————————————————————————————————————————");
                switch(select) {
                    case 1:add();break;
                    case 2:subtract();break;
                    case 3:multiply();break;
                    case 4:divide();break;
                    case 0:System.out.println("程序即将退出...");break;
                    default:System.out.println("错误，请输入0-4的数字");
                }
                if(select == 0){
                    break;
                }
            }
		}
        public static void add() {
            int n1,n2;
            int add;
            Scanner scanner = new Scanner(System.in);
            System.out.println("输入两个数相加");
            System.out.print("输入一个数:");
            n1=scanner.nextInt();
            System.out.print("输入第二个数:");
            n2=scanner.nextInt();
            if(n1!=0){
                    add=n1+n2;
                    System.out.println(n1+"+"+n2+"="+add);
            }

            }
        public static void subtract() {
                int n1,n2;
                int subtract;
                Scanner scanner = new Scanner(System.in);
                System.out.println("输入两个数相减");
                System.out.print("输入一个数:");
                n1=scanner.nextInt();
                System.out.print("输入第二个数:");
                n2=scanner.nextInt();
                if(n1!=0){
                        subtract=n1-n2;
                        System.out.println(n1+"-"+n2+"="+subtract);
                }
                }
        public static void multiply(){
            int n1,n2;
            int multiply;
            Scanner scanner = new Scanner(System.in);
            System.out.println("输入两个数乘");
            System.out.print("输入一个数:");
            n1=scanner.nextInt();
            System.out.print("输入第二个数:");
            n2=scanner.nextInt();
            if(n1!=0){
                multiply=n1*n2;
                System.out.println(n1+"*"+n2+"="+multiply);
            }
        }
        public static void divide() {
        int n1,n2;
        int multiply;
        Scanner scanner = new Scanner(System.in);
        System.out.println("输入两个数除");
        System.out.print("输入一个数:");
        n1=scanner.nextInt();
        System.out.print("输入第二个数:");
        n2=scanner.nextInt();
        if(n1!=0){
            multiply=n1/n2;
            System.out.println(n1+"/"+n2+"="+multiply);
        }
    }

}
