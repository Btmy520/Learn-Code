package com.itheima.demotest.demo;
import java.util.Scanner;
public class JavaDemo03 {
    public static void main(String[] args) {
        //键盘录入两个整数
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入本人衣服时髦程度:");
        int fashion = sc.nextInt();
        System.out.println("请输入对方衣服时髦程度:");
        int girlfashion = sc.nextInt();
        if(fashion > girlfashion){
            System.out.println("I love you babe~");
        }else{
            System.out.println("可惜不是你");
        }
    }
}
