package com.itheima.demotest.demo;

import java.util.Scanner;

public class Primenumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("输入一个正整数: ");
        int number = sc.nextInt();
        boolean flag = true;
        for (int i = 2; i < number; i++) {
            flag = false;
            break;
        }
        if (flag) {
            System.out.println("Prime number: " + number);
        }else{
            System.out.println("Not Prime number: " + number);
        }
    }
}
