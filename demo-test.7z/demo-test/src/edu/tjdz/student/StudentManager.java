package edu.tjdz.student;

import java.util.ArrayList;
import java.util.List;

public class StudentManager {
    private List<Student> studentDataBase = new ArrayList<>();

    public Student getStudentById(String studentId){
        for (Student student: studentDataBase){
            if (student.getStudentId().equals(studentId)){
                return student;
            }
        }
        return null;
    }

    public boolean addStudent(Student studentId){
        if (getStudentById(studentId.getStudentId())!= null){
            return false;
        }
        studentDataBase.add(studentId);
        return true;
    }

    public boolean deleteStudent(String studentId){
        Student student = getStudentById(studentId);
        if (student == null){
            return false;
        }
        studentDataBase.remove(student);
        return true;
    }
    public boolean updateStudent(Student student){
        Student student1 = getStudentById(student.getStudentId());
        if (student1 == null){
            return false;
        }
        studentDataBase.remove(student1);
        studentDataBase.add(student);
        return true;
    }

    public void printAllStudents(){
        for (Student student: studentDataBase){
            System.out.println(student);
        }
    }
}
