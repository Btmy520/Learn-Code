package edu.tjdz.student;

public class App {
    public static void main(String[] args) {
        ConsoleUI consoleUI = new ConsoleUI();
        consoleUI.showMainMenu();
    }
}
