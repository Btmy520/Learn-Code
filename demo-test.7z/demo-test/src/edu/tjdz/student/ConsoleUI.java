package edu.tjdz.student;

import java.util.Scanner;

public class ConsoleUI {
    private StudentManager sM;
//    public Scanner sc;

    //主菜单
    public void showMainMenu() {
        while (true) {
            System.out.println("欢迎使用学生管理系统");
            System.out.println("1.添加学生");
            System.out.println("2.删除学生");
            System.out.println("3.修改学生");
            System.out.println("4.查询学生");
            System.out.println("0.退出系统");
            System.out.println("请输入数字:");
            System.out.println("----------------------------------------------------");
            Scanner sc = new Scanner(System.in);
            String number = sc.next();
            switch (number) {
                case "1":
                    addStudent();
                    break;
                case "2":
                    delStudentInfo();
                    break;
                case "3":
                    updateStudentInfo();
                    break;
                case "4":
                    schStudentInfo();
                    break;
                case "0":
                    System.out.println("程序即将结束...");
                    break;
                default:
                    System.out.println("数字错误,请输入0-4之间的整数! 即将返回...");
            }
        }
    }
    public void addStudent() {
            System.out.println("添加学生");
            System.out.println("----------------------------------------------------");
            System.out.println("请输入学生学号:");
            Scanner sc = new Scanner(System.in);
            String studentId = sc.next();
            if (sM.getStudentById(studentId) != null) {
                System.out.println("该学号已存在,请重新输入");

            }

    }

    public void delStudentInfo() {
            System.out.println("删除学生");
            System.out.println("----------------------------------------------------");
            System.out.println("请输入学生学号:");
            Scanner sc = new Scanner(System.in);
            String studentId = sc.next();
            if (sM.getStudentById(studentId) == null) {
                System.out.println("该学号不存在,请重新输入");
            }
    }

    public void updateStudentInfo() {
            System.out.println("修改学生");
            System.out.println("----------------------------------------------------");
            System.out.println("请输入学生学号:");
            Scanner sc = new Scanner(System.in);
            String studentId = sc.next();
            if (sM.getStudentById(studentId) == null) {
                System.out.println("该学号不存在,请重新输入");
            }

    }


    public void schStudentInfo() {
            System.out.println("查询学生");
            System.out.println("----------------------------------------------------");
            System.out.println("请输入学生学号:");
            Scanner sc = new Scanner(System.in);
            String studentId = sc.next();
            if (sM.getStudentById(studentId) == null) {
                System.out.println("该学号不存在,请重新输入");
            }
    }
}
