// StudentUI.java
package edu.tjdz.student.school.view;

import edu.tjdz.student.school.model.Student;
import edu.tjdz.student.school.service.StudentService;

import java.util.List;

public class StudentUI extends ConsoleUI {
    private final StudentService service = new StudentService();

    private void printStudentMenu() {
        System.out.println("\n=== 学生信息管理 ===");
        System.out.println("1. 添加学生");
        System.out.println("2. 删除学生");
        System.out.println("3. 修改学生");
        System.out.println("4. 查询所有学生");
        System.out.println("5. 按学号查询");
        System.out.println("0. 返回主菜单");
        System.out.print("请选择操作：");
    }

    public void showMenu() {
        while (true) {
            printStudentMenu();
            int choice = getIntInput("");
            switch (choice) {
                case 1 -> addStudent();
                case 2 -> deleteStudent();
                case 3 -> updateStudent();
                case 4 -> showAllStudents();
                case 5 -> searchStudentById();
                case 0 -> { return; }
                default -> System.out.println("无效选项，请重新选择！");
            }
        }
    }

    private void addStudent() {
        System.out.println("\n--- 添加学生 ---");
        Student student = new Student();
        student.setStuId(getStringInput("学号："));
        student.setName(getStringInput("姓名："));
        student.setAge(getIntInput("年龄："));
        student.setSex(getStringInput("性别："));
        student.setSchool(getStringInput("学校："));
        student.setStuClass(getStringInput("班级："));

        showOperationResult(service.add(student));
    }

    private void deleteStudent() {
        System.out.println("\n--- 删除学生 ---");
        String id = getStringInput("请输入要删除的学号：");
        showOperationResult(service.delete(id));
    }

    private void updateStudent() {
        System.out.println("\n--- 修改学生 ---");
        String id = getStringInput("请输入要修改的学号：");
        Student target = service.getById(id);
        if (target == null) {
            System.out.println("学生不存在！");
            return;
        }

        Student newStudent = new Student();
        newStudent.setStuId(id);
        newStudent.setName(getStringInput("新姓名（原：" + target.getName() + "）："));
        newStudent.setAge(getIntInput("新年龄（原：" + target.getAge() + "）："));
        newStudent.setSex(getStringInput("新性别（原：" + target.getSex() + "）："));
        newStudent.setSchool(getStringInput("新学校（原：" + target.getSchool() + "）："));
        newStudent.setStuClass(getStringInput("新班级（原：" + target.getStuClass() + "）："));

        showOperationResult(service.update(id, newStudent));
    }

    private void showAllStudents() {
        System.out.println("\n--- 所有学生信息 ---");
        List<Student> students = service.getAll();
        if (students.isEmpty()) {
            System.out.println("暂无学生信息！");
            return;
        }

        System.out.printf("%-12s%-8s%-6s%-8s%-20s%-15s%n",
                "学号", "姓名", "年龄", "性别", "学校", "班级");
        students.forEach(s -> System.out.printf("%-12s%-8s%-6d%-8s%-20s%-15s%n",
                s.getStuId(), s.getName(), s.getAge(), s.getSex(),
                s.getSchool(), s.getStuClass()));
    }

    private void searchStudentById() {
        System.out.println("\n--- 学生查询 ---");
        Student s = service.getById(getStringInput("请输入学号："));
        if (s == null) {
            System.out.println("未找到该学生！");
            return;
        }
        System.out.printf("%n学号：%s%n姓名：%s%n年龄：%d%n性别：%s%n学校：%s%n班级：%s%n",
                s.getStuId(), s.getName(), s.getAge(), s.getSex(), s.getSchool(), s.getStuClass());
    }
}