// ConsoleUI.java
package edu.tjdz.student.school.view;

import java.util.Scanner;

public class ConsoleUI {
    protected final Scanner scanner = new Scanner(System.in);

    protected void printMainMenu() {
        System.out.println("\n=== 学校信息管理系统 ===");
        System.out.println("1. 学生信息管理");
        System.out.println("2. 教师信息管理");
        System.out.println("0. 退出系统");
        System.out.print("请选择操作：");
    }

    protected int getIntInput(String prompt) {
        System.out.print(prompt);
        while (!scanner.hasNextInt()) {
            System.out.println("输入错误，请重新输入！");
            scanner.next();
            System.out.print(prompt);
        }
        int input = scanner.nextInt();
        scanner.nextLine(); // 清除换行符
        return input;
    }

    protected String getStringInput(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    protected void showOperationResult(boolean success) {
        System.out.println(success ? "操作成功！" : "操作失败！");
    }

    public void showMenu() {
        while (true) {
            printMainMenu();
            int choice = getIntInput("");
            switch (choice) {
                case 1 -> new StudentUI().showMenu();
                case 2 -> new TeacherUI().showMenu();
                case 0 -> {
                    System.out.println("感谢使用，再见！");
                    System.exit(0);
                }
                default -> System.out.println("无效选项，请重新选择！");
            }
        }
    }
}