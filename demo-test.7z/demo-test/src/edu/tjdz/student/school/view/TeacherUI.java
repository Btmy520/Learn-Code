// TeacherUI.java
package edu.tjdz.student.school.view;

import edu.tjdz.student.school.model.Teacher;
import edu.tjdz.student.school.service.TeacherService;

import java.util.List;

public class TeacherUI extends ConsoleUI {
    private final TeacherService service = new TeacherService();

    private void printTeacherMenu() {
        System.out.println("\n=== 教师信息管理 ===");
        System.out.println("1. 添加教师");
        System.out.println("2. 删除教师");
        System.out.println("3. 修改教师");
        System.out.println("4. 查询所有教师");
        System.out.println("5. 按工号查询");
        System.out.println("0. 返回主菜单");
        System.out.print("请选择操作：");
    }

    public void showMenu() {
        while (true) {
            printTeacherMenu();
            int choice = getIntInput("");
            switch (choice) {
                case 1 -> addTeacher();
                case 2 -> deleteTeacher();
                case 3 -> updateTeacher();
                case 4 -> showAllTeachers();
                case 5 -> searchTeacherById();
                case 0 -> { return; }
                default -> System.out.println("无效选项，请重新选择！");
            }
        }
    }

    private void addTeacher() {
        System.out.println("\n--- 添加教师 ---");
        Teacher teacher = new Teacher();
        teacher.setTeacherId(getStringInput("工号："));
        teacher.setName(getStringInput("姓名："));
        teacher.setAge(getIntInput("年龄："));
        teacher.setSex(getStringInput("性别："));
        teacher.setSchool(getStringInput("学校："));
        teacher.setTeachClass(getStringInput("授课班级："));

        showOperationResult(service.add(teacher));
    }

    private void deleteTeacher() {
        System.out.println("\n--- 删除教师 ---");
        String id = getStringInput("请输入要删除的工号：");
        showOperationResult(service.delete(id));
    }

    private void updateTeacher() {
        System.out.println("\n--- 修改教师 ---");
        String id = getStringInput("请输入要修改的工号：");
        Teacher target = service.getById(id);
        if (target == null) {
            System.out.println("教师不存在！");
            return;
        }

        Teacher newTeacher = new Teacher();
        newTeacher.setTeacherId(id);
        newTeacher.setName(getStringInput("新姓名（原：" + target.getName() + "）："));
        newTeacher.setAge(getIntInput("新年龄（原：" + target.getAge() + "）："));
        newTeacher.setSex(getStringInput("新性别（原：" + target.getSex() + "）："));
        newTeacher.setSchool(getStringInput("新学校（原：" + target.getSchool() + "）："));
        newTeacher.setTeachClass(getStringInput("新授课班级（原：" + target.getTeachClass() + "）："));

        showOperationResult(service.update(id, newTeacher));
    }

    private void showAllTeachers() {
        System.out.println("\n--- 所有教师信息 ---");
        List<Teacher> teachers = service.getAll();
        if (teachers.isEmpty()) {
            System.out.println("暂无教师信息！");
            return;
        }

        System.out.printf("%-12s%-8s%-6s%-8s%-20s%-15s%n",
                "工号", "姓名", "年龄", "性别", "学校", "授课班级");
        teachers.forEach(t -> System.out.printf("%-12s%-8s%-6d%-8s%-20s%-15s%n",
                t.getTeacherId(), t.getName(), t.getAge(), t.getSex(),
                t.getSchool(), t.getTeachClass()));
    }

    private void searchTeacherById() {
        System.out.println("\n--- 教师查询 ---");
        Teacher t = service.getById(getStringInput("请输入工号："));
        if (t == null) {
            System.out.println("未找到该教师！");
            return;
        }
        System.out.printf("%n工号：%s%n姓名：%s%n年龄：%d%n性别：%s%n学校：%s%n授课班级：%s%n",
                t.getTeacherId(), t.getName(), t.getAge(), t.getSex(), t.getSchool(), t.getTeachClass());
    }
}