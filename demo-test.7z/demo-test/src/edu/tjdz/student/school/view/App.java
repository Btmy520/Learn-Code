package edu.tjdz.student.school.view;

public class App {
    public static void main(String[] args) {
        new ConsoleUI().showMenu();
    }
}
