package edu.tjdz.student.school.model;

public class Student extends Person{
    private String stuId;
    private String stuClass;

    public Student() {

    }

    public Student(String stuId, String stuClass) {
        this.stuId = stuId;
        this.stuClass = stuClass;
    }

    /**
     * 获取
     * @return stuId
     */
    public String getStuId() {
        return stuId;
    }

    /**
     * 设置
     * @param stuId
     */
    public void setStuId(String stuId) {
        this.stuId = stuId;
    }

    /**
     * 获取
     * @return stuClass
     */
    public String getStuClass() {
        return stuClass;
    }

    /**
     * 设置
     * @param stuClass
     */
    public void setStuClass(String stuClass) {
        this.stuClass = stuClass;
    }

    public String toString() {
        return "Student{stuId = " + stuId + ", stuClass = " + stuClass + "}";
    }

    public String study() {
    	return "学生正在上课";
    }
}
