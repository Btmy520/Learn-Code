package edu.tjdz.student.school.model;

public class App {
    public static void main(String[] args) {
        Student student = new Student("20160001", "软件工程");
        student.setName("btmy");
        student.setAge(1143);
        student.setSex("男");
        System.out.println(student.getName() + student.getAge() + student.getSex());
        System.out.println(student.study());
    }
}
