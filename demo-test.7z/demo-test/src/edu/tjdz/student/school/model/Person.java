package edu.tjdz.student.school.model;

public class Person {
    private String school;
    private String name;
    private String sex;
    private int age;

    public Person() {
    }

    public Person(String school, String name, String sex, int age) {
        this.school = school;
        this.name = name;
        this.sex = sex;
        this.age = age;
    }

    /**
     * 获取
     * @return school
     */
    public String getSchool() {
        return school;
    }

    /**
     * 设置
     * @param school
     */
    public void setSchool(String school) {
        this.school = school;
    }

    /**
     * 获取
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * 设置
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取
     * @return sex
     */
    public String getSex() {
        return sex;
    }

    /**
     * 设置
     * @param sex
     */
    public void setSex(String sex) {
        this.sex = sex;
    }

    /**
     * 获取
     * @return age
     */
    public int getAge() {
        return age;
    }

    /**
     * 设置
     * @param age
     */
    public void setAge(int age) {
        this.age = age;
    }

    public String toString() {
        return "Person{school = " + school + ", name = " + name + ", sex = " + sex + ", age = " + age + "}";
    }
}
