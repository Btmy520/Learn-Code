package edu.tjdz.student.school.model;

public class Teacher extends Person{
    private String teacherId;
    private String teachClass;

    public Teacher() {
    	super();
    }

    public Teacher(String teacherId, String teachClass) {
        this.teacherId = teacherId;
        this.teachClass = teachClass;
    }

    /**
     * 获取
     * @return teacherId
     */
    public String getTeacherId() {
        return teacherId;
    }

    /**
     * 设置
     * @param teacherId
     */
    public void setTeacherId(String teacherId) {
        this.teacherId = teacherId;
    }

    /**
     * 获取
     * @return teachClass
     */
    public String getTeachClass() {
        return teachClass;
    }

    /**
     * 设置
     * @param teachClass
     */
    public void setTeachClass(String teachClass) {
        this.teachClass = teachClass;
    }

    public String toString() {
        return "Teacher{teacherId = " + teacherId + ", teachClass = " + teachClass + "}";
    }

    public String Teach() {
        return "老师在讲课";
    }
}
