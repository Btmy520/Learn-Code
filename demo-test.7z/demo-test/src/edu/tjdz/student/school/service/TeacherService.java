package edu.tjdz.student.school.service;

import edu.tjdz.student.school.model.Teacher;

import java.util.ArrayList;
import java.util.List;

public class TeacherService implements PersonService<Teacher>{
    private final List<Teacher> teachers = new ArrayList<>();

    @Override
    public boolean add(Teacher teacher) {
        if (teacher == null || getById(teacher.getTeacherId()) != null) return false;
        return teachers.add(teacher);
    }

    @Override
    public boolean delete(String id) {
        Teacher target = getById(id);
        return target != null && teachers.remove(target);
    }

    @Override
    public boolean update(String id, Teacher newTeacher) {
        Teacher target = getById(id);
        if (target == null) return false;

        // 同步更新Person基类属性
        target.setName(newTeacher.getName());
        target.setAge(newTeacher.getAge());
        target.setSex(newTeacher.getSex());
        target.setSchool(newTeacher.getSchool());

        // 更新子类特有属性
        target.setTeachClass(newTeacher.getTeachClass());
        return true;
    }

    @Override
    public Teacher getById(String id) {
        return teachers.stream()
                .filter(t -> t.getTeacherId().equals(id))
                .findFirst()
                .orElse(null);
    }

    @Override
    public List<Teacher> getAll() {
        return new ArrayList<>(teachers);
    }
}
