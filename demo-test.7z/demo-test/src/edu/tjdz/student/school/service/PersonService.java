package edu.tjdz.student.school.service;

import edu.tjdz.student.school.model.Person;

import java.util.List;

//接口
public interface PersonService <T extends Person>{
    boolean add(T Person);
    boolean delete(String id);
    boolean update(String id, T newPerson);
    T getById(String id);
    List<T> getAll();

}
