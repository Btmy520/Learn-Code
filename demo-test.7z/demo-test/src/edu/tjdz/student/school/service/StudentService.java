package edu.tjdz.student.school.service;

import edu.tjdz.student.school.model.Student;
import java.util.ArrayList;
import java.util.List;

public class StudentService implements PersonService<Student> {
    private final List<Student> students = new ArrayList<>();

    @Override
    public boolean add(Student student) {
        if (student == null || getById(student.getStuId()) != null) return false;
        return students.add(student);
    }

    @Override
    public boolean delete(String id) {
        Student target = getById(id);
        return target != null && students.remove(target);
    }

    @Override
    public boolean update(String id, Student newStudent) {
        Student target = getById(id);
        if (target == null) return false;

        // 同步更新Person基类属性
        target.setName(newStudent.getName());
        target.setAge(newStudent.getAge());
        target.setSex(newStudent.getSex());
        target.setSchool(newStudent.getSchool());

        // 更新子类特有属性
        target.setStuClass(newStudent.getStuClass());
        return true; // 直接修改对象，无需删除后添加
    }

    @Override
    public Student getById(String id) {
        return students.stream()
                .filter(s -> s.getStuId().equals(id))
                .findFirst()
                .orElse(null);
    }

    @Override
    public List<Student> getAll() {
        return new ArrayList<>(students);
    }
}
