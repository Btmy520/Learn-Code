package edu.tjdz.student.user;

import java.util.Scanner;

public class Menu {
    private final Scanner inputScanner = new Scanner(System.in);
    private final UserManager userManager;

    public Menu(UserManager userManager) {
        this.userManager = userManager;
    }

    public void showMainMenu() {
        while (true) {
            printMenu();
            int choice = getValidInput();

            switch (choice) {
                case 1 -> registrationMenu();
                case 2 -> loginMenu();
                case 0 -> {
                    System.out.println("系统已退出！");
                    return;
                }
                default -> System.out.println("无效选项，请重新选择！");
            }
        }
    }

    private void printMenu() {
        System.out.println("\n=== 欢迎使用身份验证系统 ===");
        System.out.println("1. 注册");
        System.out.println("2. 登录");
        System.out.println("0. 退出");
        System.out.print("请输入你的选择：");
    }

    private int getValidInput() {
        while (true) {
            try {
                int input = Integer.parseInt(inputScanner.nextLine());
                if (input >= 0 && input <= 2) return input;
                System.out.print("输入无效，请重新选择（0-2）：");
            } catch (NumberFormatException e) {
                System.out.print("请输入数字：");
            }
        }
    }

    private void registrationMenu() {
        System.out.println("\n=== 用户注册 ===");
        System.out.print("输入用户名：");
        String userName = inputScanner.nextLine().trim();
        System.out.print("输入密码：");
        String password = inputScanner.nextLine().trim();

        if (userManager.registerUser(userName, password)) {
            System.out.println("注册成功！");
        } else {
            System.out.println("用户名已存在！");
        }
    }

    private void loginMenu() {
        System.out.println("\n=== 用户登录 ===");
        System.out.print("输入用户名：");
        String userName = inputScanner.nextLine().trim();
        System.out.print("输入密码：");
        String password = inputScanner.nextLine().trim();

        if (userManager.loginUser(userName, password)) {
            System.out.println("登录成功！");
        } else {
            System.out.println("认证失败！");
        }
    }
}
