package edu.tjdz.student.user;

import java.util.ArrayList;
import java.util.List;

public class UserManager {
    private List<User> users = new ArrayList<>();

    public boolean registerUser(String userName, String password) {
        if (usernameJudge(userName)) {
            return false;
        }
        users.add(new User(userName, password));
        return true;
    }

    public boolean loginUser(String userName, String password) {
        return users.stream().anyMatch(u -> u.getUserName().equals(userName) && u.getPassword().equals(password)
        );
    }

    private boolean usernameJudge(String userName) {
        return users.stream().anyMatch(u -> u.getUserName().equals(userName));
    }
}