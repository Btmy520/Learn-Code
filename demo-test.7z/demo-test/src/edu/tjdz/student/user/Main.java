package edu.tjdz.student.user;

public class Main {
    public static void main(String[] args) {
        UserManager userManager = new UserManager();
        Menu mainMenu = new Menu(userManager);
        mainMenu.showMainMenu();
    }
}
